export default function PaginaEvento() {
  return (
    <div>
      <span>Evento</span>
    </div>
  );
}
