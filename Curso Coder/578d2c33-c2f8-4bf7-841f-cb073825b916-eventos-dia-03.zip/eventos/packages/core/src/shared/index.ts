import Alias from "./Alias";
import Id from "./Id";
import Senha from "./Senha";
import Data from "./Data";

export { Alias, Id, Senha, Data };
