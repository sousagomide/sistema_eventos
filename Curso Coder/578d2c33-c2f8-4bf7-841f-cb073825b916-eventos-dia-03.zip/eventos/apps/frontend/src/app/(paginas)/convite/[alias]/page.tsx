export default function PaginaConvite(props: any) {
  return (
    <div>
      <span>{props.params.alias}</span>
    </div>
  );
}
