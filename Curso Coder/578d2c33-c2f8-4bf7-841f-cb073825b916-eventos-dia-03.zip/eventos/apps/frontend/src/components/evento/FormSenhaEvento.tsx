export default function FormSenhaEvento() {
  return (
    <div>
      <span>FormSenhaEvento</span>
    </div>
  );
}
